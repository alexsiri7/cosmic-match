// Main app — shell that holds the android frame, screen routing, and tweaks wiring.

const { useState, useEffect, useMemo, useRef } = React;

function App() {
  const [tweaks, setTweaks] = useState(() => window.TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  const [tweaksAvailable, setTweaksAvailable] = useState(false);

  // Persisted screen state (independent of tweak.screen, but tweak.screen forces a jump)
  const [screen, setScreen] = useState(() => {
    try { return localStorage.getItem('cm_screen') || tweaks.screen || 'home'; }
    catch { return tweaks.screen || 'home'; }
  });
  const [level, setLevel] = useState(() => {
    try { return parseInt(localStorage.getItem('cm_level')) || 1; }
    catch { return 1; }
  });
  const [progress, setProgress] = useState(() => {
    try {
      const v = JSON.parse(localStorage.getItem('cm_progress'));
      if (v) return v;
    } catch {}
    return { current: 3, stars: 2, totalStars: 5, allStars: {1:3, 2:2} };
  });
  const [modal, setModal] = useState(null); // {type, data}

  // Persist
  useEffect(() => { try { localStorage.setItem('cm_screen', screen); } catch {} }, [screen]);
  useEffect(() => { try { localStorage.setItem('cm_level', level); } catch {} }, [level]);
  useEffect(() => { try { localStorage.setItem('cm_progress', JSON.stringify(progress)); } catch {} }, [progress]);

  // Tweak.screen → screen (when tweaks explicitly set)
  useEffect(() => {
    if (tweaks.screen && tweaks.screen !== screen) setScreen(tweaks.screen);
  }, [tweaks.screen]);

  // Tweaks mode wiring with host
  useEffect(() => {
    function onMsg(e) {
      if (e.data?.type === '__activate_edit_mode') setTweaksOpen(true);
      else if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    }
    window.addEventListener('message', onMsg);
    try {
      window.parent.postMessage({type: '__edit_mode_available'}, '*');
      setTweaksAvailable(true);
    } catch {}
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const updateTweaks = (patch) => {
    setTweaks(t => ({...t, ...patch}));
    try {
      window.parent.postMessage({type: '__edit_mode_set_keys', edits: patch}, '*');
    } catch {}
  };

  const nav = {
    home:   () => { setScreen('home'); updateTweaks({screen:'home'}); },
    map:    () => { setScreen('map');  updateTweaks({screen:'map'}); },
    game:   (lvl) => { if (lvl) setLevel(lvl); setScreen('game'); updateTweaks({screen:'game'}); },
    win:    (stars, score) => setModal({type:'win', stars, score}),
    fail:   (score) => setModal({type:'fail', score}),
  };

  return (
    <>
      <div style={{
        position: 'relative', zIndex: 1,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18,
      }}>
        <div style={{
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 10, letterSpacing: 2.5,
          color: 'rgba(255,255,255,0.5)',
          textAlign: 'center',
        }}>
          COSMIC MATCH · INTERACTIVE PROTOTYPE
          <div style={{fontSize: 9, marginTop: 4, opacity: 0.6, letterSpacing: 1.2}}>
            Tap tiles to swap · 3+ to match · 4 → Pulsar · 5 → Supernova · L/T → Black Hole
          </div>
        </div>
        <PhoneWrapper>
          {screen === 'home' && (
            <HomeScreen
              galaxy={tweaks.galaxy}
              progress={progress}
              onPlay={() => nav.game(progress.current)}
              onMap={nav.map}
              onSettings={() => setTweaksOpen(true)}/>
          )}
          {screen === 'map' && (
            <MapScreen
              galaxy={tweaks.galaxy}
              progress={progress}
              onLevel={(lvl) => nav.game(lvl)}
              onBack={nav.home}/>
          )}
          {screen === 'game' && (
            <GameScreen
              key={level + tweaks.boardSize}
              galaxy={tweaks.galaxy}
              level={level}
              tileStyle={tweaks.tileStyle}
              boardSize={tweaks.boardSize || 8}
              onWin={(stars, score) => nav.win(stars, score)}
              onFail={(score) => nav.fail(score)}
              onBack={nav.map}/>
          )}
          {modal?.type === 'win' && (
            <LevelCompleteModal
              galaxy={tweaks.galaxy} level={level}
              stars={modal.stars} score={modal.score}
              onContinue={() => {
                setProgress(p => ({
                  ...p,
                  current: Math.min(10, Math.max(p.current, level + 1)),
                  stars: modal.stars,
                  totalStars: (p.totalStars || 0) + modal.stars,
                  allStars: {...(p.allStars||{}), [level]: Math.max((p.allStars||{})[level]||0, modal.stars)},
                }));
                setLevel(l => l + 1);
                setModal(null);
              }}
              onReplay={() => setModal(null)}/>
          )}
          {modal?.type === 'fail' && (
            <LevelFailedModal
              galaxy={tweaks.galaxy} level={level} score={modal.score}
              onRetry={() => { setModal(null); setScreen('game'); }}
              onQuit={() => { setModal(null); nav.map(); }}/>
          )}
        </PhoneWrapper>
        {/* Quick jump bar — always visible for reviewer convenience */}
        <div style={{
          display: 'flex', gap: 8,
          padding: 4,
          background: 'rgba(255,255,255,0.04)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 100,
        }}>
          {[['home','Home'],['map','Map'],['game','Game']].map(([k, l]) => (
            <button key={k} onClick={() => { setScreen(k); updateTweaks({screen: k}); }}
              style={{
                padding: '8px 16px', borderRadius: 100,
                background: screen === k ? 'rgba(255,255,255,0.14)' : 'transparent',
                border: 'none', color: screen === k ? '#fff' : 'rgba(255,255,255,0.6)',
                fontSize: 12, cursor: 'pointer',
                fontFamily: "'IBM Plex Mono', monospace", letterSpacing: 1,
              }}>{l.toUpperCase()}</button>
          ))}
        </div>
      </div>

      <TweaksPanel
        state={tweaks}
        onChange={updateTweaks}
        visible={tweaksOpen}
        onClose={() => setTweaksOpen(false)}/>
    </>
  );
}

function PhoneWrapper({ children }) {
  // Simple device frame — android_frame is overkill here since game is
  // full-bleed and owns its own status area.
  return (
    <div style={{
      width: 412, height: 892,
      borderRadius: 44, overflow: 'hidden',
      background: '#000',
      border: '10px solid #1a1622',
      boxShadow: '0 40px 100px rgba(0,0,0,0.6), inset 0 0 0 2px rgba(255,255,255,0.04)',
      position: 'relative',
    }} data-screen-label="Cosmic Match">
      {/* punch-hole camera */}
      <div style={{
        position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
        width: 22, height: 22, borderRadius: 100, background: '#000',
        border: '1px solid #2a2330',
        zIndex: 100,
      }}/>
      {/* status bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 40,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 24px',
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 12, color: '#fff',
        zIndex: 99, pointerEvents: 'none',
      }}>
        <span>9:30</span>
        <span style={{display:'flex', alignItems:'center', gap: 4, fontSize: 11, opacity: 0.85}}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
            <path d="M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9z"/>
          </svg>
          98%
        </span>
      </div>
      <div style={{position:'absolute', inset: 0, paddingTop: 40}}>
        <div style={{width: '100%', height: 'calc(100% - 14px)'}}>{children}</div>
      </div>
      {/* gesture pill */}
      <div style={{
        position: 'absolute', bottom: 6, left: '50%',
        transform: 'translateX(-50%)',
        width: 128, height: 4, borderRadius: 10,
        background: 'rgba(255,255,255,0.5)', zIndex: 99,
      }}/>
    </div>
  );
}

// Global keyframes
const styleEl = document.createElement('style');
styleEl.textContent = `
  @keyframes twinkle {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 1; }
  }
  @keyframes tilepulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }
  @keyframes bonusspin {
    0% { filter: brightness(1); }
    50% { filter: brightness(1.3); }
    100% { filter: brightness(1); }
  }
  @keyframes comboflash {
    0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); }
    25% { opacity: 1; transform: translate(-50%, -50%) scale(1.15); }
    100% { opacity: 0; transform: translate(-50%, -80%) scale(1); }
  }
  @keyframes starpop {
    0% { opacity: 0; transform: scale(0.3) rotate(-20deg); }
    60% { opacity: 1; transform: scale(1.2) rotate(5deg); }
    100% { opacity: 1; transform: scale(1) rotate(0); }
  }
  @keyframes modalin {
    0% { opacity: 0; transform: translateY(20px) scale(0.96); }
    100% { opacity: 1; transform: translateY(0) scale(1); }
  }
`;
document.head.appendChild(styleEl);

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
