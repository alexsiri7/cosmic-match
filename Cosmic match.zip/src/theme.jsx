// Galaxy palettes + tile colors.
// Ink base + 2-color nebula wash per galaxy. Tile hues retuned from the
// dev placeholder hexes to more considered oklch values that still read as
// red/blue/yellow/purple/white/orange per the PRD.

const GALAXIES = {
  lyra: {
    name: 'Lyra',
    subtitle: 'The Harp',
    ink: '#0d0a1a',
    nebulaA: 'oklch(0.38 0.18 300)', // violet
    nebulaB: 'oklch(0.42 0.15 220)', // cyan
    accent: 'oklch(0.82 0.15 300)',
    stroke: 'oklch(0.55 0.12 285)',
  },
  orion: {
    name: 'Orion',
    subtitle: 'The Hunter',
    ink: '#150b08',
    nebulaA: 'oklch(0.40 0.17 35)',  // rust
    nebulaB: 'oklch(0.45 0.14 85)',  // gold
    accent: 'oklch(0.82 0.15 60)',
    stroke: 'oklch(0.55 0.14 40)',
  },
  andromeda: {
    name: 'Andromeda',
    subtitle: 'The Chained',
    ink: '#0a1412',
    nebulaA: 'oklch(0.40 0.14 180)',
    nebulaB: 'oklch(0.42 0.15 340)',
    accent: 'oklch(0.82 0.14 180)',
    stroke: 'oklch(0.55 0.12 200)',
  },
  cassiopeia: {
    name: 'Cassiopeia',
    subtitle: 'The Queen',
    ink: '#0e1008',
    nebulaA: 'oklch(0.40 0.15 130)',
    nebulaB: 'oklch(0.42 0.16 260)',
    accent: 'oklch(0.85 0.15 130)',
    stroke: 'oklch(0.55 0.13 130)',
  },
};

// 6 tile types — PRD names on the left, presentation hex on the right.
// "white" reads as a pale moon (cool off-white) not pure #EEE which looks flat.
const TILES = {
  red:    { name: 'Mars',    color: '#E85A47', glow: 'oklch(0.75 0.17 30)' },
  blue:   { name: 'Neptune', color: '#4B7BE5', glow: 'oklch(0.72 0.14 250)' },
  yellow: { name: 'Sol',     color: '#F5C24B', glow: 'oklch(0.88 0.14 85)' },
  purple: { name: 'Nebula',  color: '#A96BE8', glow: 'oklch(0.72 0.18 300)' },
  white:  { name: 'Luna',    color: '#E4E2F5', glow: 'oklch(0.95 0.02 280)' },
  orange: { name: 'Comet',   color: '#F08A3E', glow: 'oklch(0.78 0.16 55)' },
};

const BONUS = {
  pulsar:    { name: 'Pulsar',    desc: 'clears the row',       color: '#FFF4C7' },
  blackhole: { name: 'Black Hole', desc: 'clears 3×3 area',     color: '#1a0f2e' },
  supernova: { name: 'Supernova', desc: 'clears one tile type', color: '#FF6BD0' },
};

Object.assign(window, { GALAXIES, TILES, BONUS });
