// Galaxy map — level select. Path of nodes winding up the screen with
// locked/unlocked states, star ratings.

function MapScreen({ galaxy, progress, onLevel, onBack }) {
  const g = GALAXIES[galaxy];
  const currentLevel = progress.current;
  const ownedStars = progress.allStars || {};

  // Generate 10 nodes in a winding path
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    const t = i / 9;
    // zigzag: alternate left/right as we go up
    const x = 50 + Math.sin(i * 0.9) * 25;
    const y = 90 - t * 78;
    nodes.push({ level: i + 1, x, y });
  }

  return (
    <div style={{
      position: 'relative',
      width: '100%', height: '100%',
      background: `radial-gradient(ellipse at 30% 80%, ${g.nebulaA} 0%, transparent 50%),
                   radial-gradient(ellipse at 70% 20%, ${g.nebulaB} 0%, transparent 50%),
                   ${g.ink}`,
      overflow: 'hidden',
    }}>
      <Starfield density={100} seed={3}/>

      {/* Path behind nodes */}
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none"
        style={{position:'absolute', inset:0}}>
        {nodes.slice(0, -1).map((n, i) => {
          const m = nodes[i+1];
          const unlocked = m.level <= currentLevel;
          return (
            <line key={i} x1={n.x} y1={n.y} x2={m.x} y2={m.y}
              stroke={unlocked ? g.accent : '#fff'}
              strokeOpacity={unlocked ? 0.5 : 0.15}
              strokeWidth="0.35"
              strokeDasharray="0.8 0.8"/>
          );
        })}
      </svg>

      {/* Header */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, zIndex: 3,
        padding: '16px 20px',
        background: `linear-gradient(180deg, ${g.ink} 0%, transparent 100%)`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <button onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 100,
          background: 'rgba(255,255,255,0.08)',
          border: '1px solid rgba(255,255,255,0.12)',
          color: '#fff', cursor: 'pointer',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
        </button>
        <div style={{textAlign: 'center'}}>
          <div style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10, letterSpacing: 2, opacity: 0.6,
          }}>GALAXY MAP</div>
          <div style={{fontSize: 18, fontWeight: 600, marginTop: 2}}>{g.name}</div>
        </div>
        <div style={{
          padding: '6px 12px', borderRadius: 100,
          background: 'rgba(255,255,255,0.08)',
          border: '1px solid rgba(255,255,255,0.12)',
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 11, display:'flex', gap: 5, alignItems:'center',
        }}>
          <svg width="10" height="10" viewBox="0 0 24 24">
            <polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9" fill={g.accent}/>
          </svg>
          {progress.totalStars || 0}
        </div>
      </div>

      {/* Nodes */}
      {nodes.map((n) => {
        const unlocked = n.level <= currentLevel;
        const isCurrent = n.level === currentLevel;
        const stars = ownedStars[n.level] || 0;
        return (
          <div key={n.level} style={{
            position: 'absolute',
            left: `${n.x}%`, top: `${n.y}%`,
            transform: 'translate(-50%, -50%)',
            zIndex: 4,
          }}>
            <button
              disabled={!unlocked}
              onClick={() => unlocked && onLevel(n.level)}
              style={{
                width: 56, height: 56, borderRadius: 100,
                background: isCurrent ? g.accent
                  : unlocked ? 'rgba(255,255,255,0.12)'
                  : 'rgba(255,255,255,0.04)',
                border: isCurrent ? 'none' : `2px solid ${unlocked ? g.accent : 'rgba(255,255,255,0.15)'}`,
                color: isCurrent ? g.ink : unlocked ? '#fff' : 'rgba(255,255,255,0.35)',
                fontSize: 20, fontWeight: 600,
                fontFamily: "'IBM Plex Mono', monospace",
                cursor: unlocked ? 'pointer' : 'not-allowed',
                display: 'flex', alignItems:'center', justifyContent:'center',
                position: 'relative',
                boxShadow: isCurrent ? `0 0 24px ${g.accent}80` : 'none',
                animation: isCurrent ? 'tilepulse 1.8s ease-in-out infinite' : 'none',
              }}>
              {unlocked ? n.level : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="5" y="11" width="14" height="10" rx="2"/>
                  <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                </svg>
              )}
            </button>
            {unlocked && (
              <div style={{
                position: 'absolute', top: '100%', left: '50%',
                transform: 'translate(-50%, 4px)',
                display: 'flex', gap: 2,
              }}>
                {[0,1,2].map(i => (
                  <svg key={i} width="9" height="9" viewBox="0 0 24 24">
                    <polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9"
                      fill={i < stars ? g.accent : 'transparent'}
                      stroke={g.accent} strokeOpacity="0.5" strokeWidth="2"/>
                  </svg>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* Footer info card */}
      <div style={{
        position: 'absolute', bottom: 16, left: 16, right: 16, zIndex: 3,
        padding: '14px 16px',
        background: 'rgba(10,7,16,0.85)',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 14,
      }}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div>
            <div style={{
              fontFamily: "'IBM Plex Mono', monospace",
              fontSize: 10, letterSpacing: 1.5, opacity: 0.55,
            }}>{g.subtitle.toUpperCase()} · SECTOR 1/5</div>
            <div style={{fontSize: 15, fontWeight: 500, marginTop: 2}}>
              {currentLevel < 10 ? `${10 - currentLevel} levels to next galaxy` : 'Galaxy complete'}
            </div>
          </div>
          <div style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 12, color: g.accent,
          }}>{currentLevel}/10</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MapScreen });
