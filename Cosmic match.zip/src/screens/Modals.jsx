// Win / fail modals + settings.

function LevelCompleteModal({ galaxy, level, stars, score, onContinue, onReplay }) {
  const g = GALAXIES[galaxy];
  return (
    <ModalShell ink={g.ink} nebA={g.nebulaA} nebB={g.nebulaB}>
      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11, letterSpacing: 2.5, opacity: 0.65,
      }}>LEVEL {String(level).padStart(2,'0')} · CLEARED</div>

      <div style={{
        margin: '12px 0 24px',
        fontSize: 44, fontWeight: 500, letterSpacing: -1.5, lineHeight: 1,
      }}>Sector<br/>complete</div>

      {/* Stars */}
      <div style={{display: 'flex', gap: 8, justifyContent: 'center', margin: '16px 0 24px'}}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            animation: `starpop 500ms ease-out ${i * 200}ms backwards`,
          }}>
            <svg width="54" height="54" viewBox="0 0 24 24">
              <polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9"
                fill={i < stars ? g.accent : 'transparent'}
                stroke={g.accent}
                strokeOpacity={i < stars ? 1 : 0.3}
                strokeWidth="1.5"
                style={{
                  filter: i < stars ? `drop-shadow(0 0 12px ${g.accent})` : 'none',
                }}/>
            </svg>
          </div>
        ))}
      </div>

      <div style={{
        padding: '14px 16px',
        background: 'rgba(255,255,255,0.06)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 12,
        width: '100%', boxSizing: 'border-box',
      }}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 8}}>
          <span style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10, letterSpacing: 1.5, opacity: 0.6,
          }}>SCORE</span>
          <span style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 20, fontWeight: 500,
          }}>{score.toLocaleString()}</span>
        </div>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <span style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10, letterSpacing: 1.5, opacity: 0.6,
          }}>REWARD</span>
          <span style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 13, color: g.accent,
          }}>+{stars * 100} COSMIC DUST</span>
        </div>
      </div>

      <button onClick={onContinue} style={{
        marginTop: 24, width: '100%', padding: '16px',
        background: g.accent, color: g.ink,
        border: 'none', borderRadius: 100,
        fontSize: 15, fontWeight: 600, letterSpacing: 0.3,
        cursor: 'pointer',
        boxShadow: `0 0 30px ${g.accent}50`,
      }}>Next Level →</button>
      <button onClick={onReplay} style={{
        marginTop: 8, width: '100%', padding: '12px',
        background: 'transparent', color: '#fff',
        border: '1px solid rgba(255,255,255,0.2)', borderRadius: 100,
        fontSize: 13, cursor: 'pointer',
      }}>Replay</button>
    </ModalShell>
  );
}

function LevelFailedModal({ galaxy, level, score, onRetry, onQuit }) {
  const g = GALAXIES[galaxy];
  return (
    <ModalShell ink={g.ink} nebA={g.nebulaA} nebB={g.nebulaB}>
      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11, letterSpacing: 2.5, opacity: 0.65, color: '#F08A3E',
      }}>LEVEL {String(level).padStart(2,'0')} · NO MOVES LEFT</div>
      <div style={{
        margin: '12px 0 24px',
        fontSize: 44, fontWeight: 500, letterSpacing: -1.5, lineHeight: 1,
      }}>Drifting in<br/>the void</div>

      {/* Sad black hole graphic */}
      <div style={{margin: '12px 0 20px'}}>
        <BonusTile type="blackhole" size={80}/>
      </div>

      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 13, opacity: 0.7, marginBottom: 20,
      }}>Score: <span style={{color: '#fff'}}>{score.toLocaleString()}</span></div>

      <button onClick={onRetry} style={{
        width: '100%', padding: '16px',
        background: g.accent, color: g.ink,
        border: 'none', borderRadius: 100,
        fontSize: 15, fontWeight: 600,
        cursor: 'pointer',
      }}>Retry</button>
      <button onClick={onQuit} style={{
        marginTop: 8, width: '100%', padding: '12px',
        background: 'transparent', color: '#fff',
        border: '1px solid rgba(255,255,255,0.2)', borderRadius: 100,
        fontSize: 13, cursor: 'pointer',
      }}>Galaxy map</button>
    </ModalShell>
  );
}

function ModalShell({ children, ink, nebA, nebB }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 30,
      background: 'rgba(0,0,0,0.6)',
      backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20,
    }}>
      <div style={{
        width: '100%', maxWidth: 340,
        padding: '28px 24px',
        background: `radial-gradient(ellipse at 50% 0%, ${nebA} 0%, transparent 60%),
                     radial-gradient(ellipse at 50% 100%, ${nebB} 0%, transparent 60%),
                     ${ink}`,
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: 20,
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        textAlign: 'center',
        animation: 'modalin 400ms cubic-bezier(.2,.9,.25,1.1)',
      }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, { LevelCompleteModal, LevelFailedModal, ModalShell });
