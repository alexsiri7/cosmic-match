// Game screen — the actual match-3 board.

function GameScreen({ galaxy, level, tileStyle, boardSize, onWin, onFail, onBack }) {
  const g = GALAXIES[galaxy];
  const N = boardSize;

  const goalSpec = React.useMemo(() => makeGoal(level), [level]);
  const [board, setBoard] = React.useState(() => makeBoard(N));
  const [selected, setSelected] = React.useState(null);
  const [clearing, setClearing] = React.useState(new Set());
  const [score, setScore] = React.useState(0);
  const [moves, setMoves] = React.useState(goalSpec.moves);
  const [cleared, setCleared] = React.useState(0); // count of goal-relevant clears
  const [busy, setBusy] = React.useState(false);
  const [combo, setCombo] = React.useState(0);
  const [comboFlash, setComboFlash] = React.useState(null);
  const [paused, setPaused] = React.useState(false);

  // End conditions
  React.useEffect(() => {
    if (cleared >= goalSpec.target && !busy) {
      const stars = moves > goalSpec.moves * 0.5 ? 3
                  : moves > goalSpec.moves * 0.25 ? 2 : 1;
      setTimeout(() => onWin(stars, score), 400);
    } else if (moves <= 0 && !busy && cleared < goalSpec.target) {
      setTimeout(() => onFail(score), 400);
    }
  }, [cleared, moves, busy]);

  // Cell size
  const cellSize = Math.floor(Math.min(364, 412 - 48) / N);
  const boardPx = cellSize * N;

  const handleTap = (r, c) => {
    if (busy || paused) return;
    if (!selected) { setSelected({r, c}); return; }
    if (selected.r === r && selected.c === c) { setSelected(null); return; }
    if (!isAdjacent(selected, {r, c})) { setSelected({r, c}); return; }

    // Attempt swap
    const swapped = swapCells(board, selected, {r, c});
    const { toClear } = findMatches(swapped);
    if (toClear.size === 0) {
      // invalid — flash both and snap back
      setBusy(true);
      setBoard(swapped);
      setTimeout(() => {
        setBoard(board);
        setSelected(null);
        setBusy(false);
      }, 280);
      return;
    }
    setSelected(null);
    setMoves(m => m - 1);
    runCascade(swapped, 0);
  };

  async function runCascade(start, depth) {
    setBusy(true);
    let b = start;
    setBoard(b);
    await sleep(180);
    let localCombo = 0;

    while (true) {
      const { toClear, bonuses } = findMatches(b);
      if (toClear.size === 0) break;
      localCombo++;
      setCombo(localCombo);
      if (localCombo >= 2) {
        setComboFlash(`×${localCombo} COMBO`);
        setTimeout(() => setComboFlash(null), 800);
      }

      // score & goal tracking
      const points = toClear.size * 10 * localCombo + bonuses.length * 50;
      setScore(s => Math.min(999999999, s + points));
      // goal: any match of the target type counts
      let goalHits = 0;
      toClear.forEach(k => {
        const [r, c] = k.split(',').map(Number);
        if (b[r][c]?.type === goalSpec.tileType) goalHits++;
      });
      if (goalHits) setCleared(x => x + goalHits);

      // animate clear
      setClearing(toClear);
      await sleep(220);
      b = clearCells(b, toClear, bonuses);
      setClearing(new Set());
      setBoard(b);
      await sleep(180);

      // gravity + refill
      b = applyGravity(b);
      setBoard(b);
      await sleep(280);

      if (localCombo > 20) break; // cascade depth cap per SEC-008
    }
    setCombo(0);
    setBusy(false);
  }

  const goalTile = TILES[goalSpec.tileType];
  const progress = Math.min(1, cleared / goalSpec.target);

  return (
    <div style={{
      position: 'relative',
      width: '100%', height: '100%',
      background: `radial-gradient(ellipse at 50% 100%, ${g.nebulaA} 0%, transparent 50%),
                   radial-gradient(ellipse at 50% 0%, ${g.nebulaB} 0%, transparent 45%),
                   ${g.ink}`,
      overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
    }}>
      <Starfield density={60} seed={level * 7}/>

      {/* HUD */}
      <div style={{
        position: 'relative', zIndex: 2,
        padding: '14px 16px 10px',
      }}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 10}}>
          <button onClick={onBack} style={{
            width: 34, height: 34, borderRadius: 100,
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: '#fff', cursor: 'pointer',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6"/>
            </svg>
          </button>
          <div style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10, letterSpacing: 2, opacity: 0.55,
          }}>LEVEL {String(level).padStart(2,'0')} · {g.name.toUpperCase()}</div>
          <button onClick={() => setPaused(p=>!p)} style={{
            width: 34, height: 34, borderRadius: 100,
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: '#fff', cursor: 'pointer',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            {paused ? '▶' : (
              <svg width="12" height="14" viewBox="0 0 12 14" fill="currentColor">
                <rect x="1" y="1" width="3" height="12"/><rect x="8" y="1" width="3" height="12"/>
              </svg>
            )}
          </button>
        </div>

        {/* Stats row */}
        <div style={{display:'flex', gap: 8}}>
          <StatCard label="SCORE" value={score.toLocaleString()} accent={g.accent} wide/>
          <StatCard label="MOVES" value={moves} accent={moves <= 5 ? '#F08A3E' : g.accent}/>
        </div>

        {/* Goal bar */}
        <div style={{
          marginTop: 10, padding: '10px 12px',
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: 12,
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'rgba(0,0,0,0.3)',
            display: 'flex', alignItems: 'center', justifyContent:'center',
            flexShrink: 0,
          }}>
            <Tile type={goalSpec.tileType} size={28}/>
          </div>
          <div style={{flex: 1}}>
            <div style={{
              fontFamily: "'IBM Plex Mono', monospace",
              fontSize: 9, letterSpacing: 1.5, opacity: 0.55,
            }}>GOAL</div>
            <div style={{fontSize: 13, fontWeight: 500, marginTop: 1}}>
              Clear {goalSpec.target} {goalTile.name}s
            </div>
            <div style={{
              marginTop: 6, height: 4, borderRadius: 10,
              background: 'rgba(255,255,255,0.08)', overflow: 'hidden',
            }}>
              <div style={{
                width: `${progress * 100}%`, height: '100%',
                background: g.accent,
                transition: 'width 400ms ease',
                boxShadow: `0 0 8px ${g.accent}`,
              }}/>
            </div>
          </div>
          <div style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 18, fontWeight: 500,
          }}>{cleared}<span style={{opacity:0.4}}>/{goalSpec.target}</span></div>
        </div>
      </div>

      {/* Board */}
      <div style={{
        flex: 1, position: 'relative', zIndex: 2,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          position: 'relative',
          width: boardPx + 16, height: boardPx + 16,
          padding: 8,
          background: 'rgba(0,0,0,0.35)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 14,
          backdropFilter: 'blur(10px)',
        }}>
          {/* Grid lines */}
          <svg width={boardPx} height={boardPx} style={{position:'absolute', top: 8, left: 8, pointerEvents:'none'}}>
            {Array.from({length: N-1}, (_,i) => (
              <React.Fragment key={i}>
                <line x1={(i+1)*cellSize} y1={0} x2={(i+1)*cellSize} y2={boardPx}
                  stroke="#fff" strokeOpacity="0.04"/>
                <line x1={0} y1={(i+1)*cellSize} x2={boardPx} y2={(i+1)*cellSize}
                  stroke="#fff" strokeOpacity="0.04"/>
              </React.Fragment>
            ))}
          </svg>

          {/* Tiles */}
          <div style={{position:'relative', width: boardPx, height: boardPx}}>
            {board.map((row, r) => row.map((tile, c) => {
              if (!tile) return null;
              const isSel = selected && selected.r === r && selected.c === c;
              const isClearing = clearing.has(`${r},${c}`);
              const TileComp = tileStyle === 'flat' ? TileFlat : Tile;
              return (
                <div key={tile.id} onClick={() => handleTap(r, c)}
                  style={{
                    position: 'absolute',
                    left: c * cellSize, top: r * cellSize,
                    width: cellSize, height: cellSize,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: busy ? 'default' : 'pointer',
                    transition: 'left 280ms ease, top 280ms ease',
                  }}>
                  <TileComp
                    type={tile.type} bonus={tile.bonus}
                    size={cellSize - 6}
                    selected={isSel}
                    clearing={isClearing}/>
                </div>
              );
            }))}
          </div>

          {/* Combo flash */}
          {comboFlash && (
            <div style={{
              position: 'absolute', top: '50%', left: '50%',
              transform: 'translate(-50%, -50%)',
              fontSize: 36, fontWeight: 700, letterSpacing: -1,
              color: g.accent,
              textShadow: `0 0 20px ${g.accent}`,
              pointerEvents: 'none',
              animation: 'comboflash 800ms ease-out forwards',
              fontFamily: "'IBM Plex Mono', monospace",
            }}>{comboFlash}</div>
          )}
        </div>
      </div>

      {/* Tile legend */}
      <div style={{
        position: 'relative', zIndex: 2,
        padding: '8px 16px 16px',
        display: 'flex', justifyContent: 'center', gap: 8,
        opacity: 0.7,
      }}>
        <div style={{
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 9, letterSpacing: 1.5,
          alignSelf: 'center',
        }}>TAP · SWAP · MATCH</div>
      </div>

      {/* Pause overlay */}
      {paused && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 20,
          background: 'rgba(10,7,16,0.85)',
          backdropFilter: 'blur(16px)',
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          gap: 16,
        }}>
          <div style={{fontSize: 28, fontWeight: 500, letterSpacing: -1}}>Paused</div>
          <button onClick={() => setPaused(false)} style={{
            padding: '12px 32px', background: g.accent, color: g.ink,
            border: 'none', borderRadius: 100, fontSize: 14, fontWeight: 600,
            cursor: 'pointer',
          }}>Resume</button>
          <button onClick={onBack} style={{
            padding: '10px 24px', background: 'transparent', color: '#fff',
            border: '1px solid rgba(255,255,255,0.2)', borderRadius: 100,
            fontSize: 13, cursor: 'pointer',
          }}>Quit to map</button>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, accent, wide }) {
  return (
    <div style={{
      flex: wide ? 2 : 1,
      padding: '10px 12px',
      background: 'rgba(255,255,255,0.06)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: 12,
    }}>
      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9, letterSpacing: 1.5, opacity: 0.55,
      }}>{label}</div>
      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 20, fontWeight: 500, marginTop: 2,
        color: accent,
      }}>{value}</div>
    </div>
  );
}

function makeGoal(level) {
  // varies goal type with level number, consistent per level
  const tiles = ['red','blue','yellow','purple','white','orange'];
  const tileType = tiles[level % tiles.length];
  const target = 20 + Math.floor(level * 2.5);
  const moves = Math.max(18, 30 - Math.floor(level * 0.8));
  return { tileType, target, moves };
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

Object.assign(window, { GameScreen, makeGoal });
