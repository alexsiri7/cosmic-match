// Home screen — game launcher with primary CTA, continue card, stats row.

function HomeScreen({ galaxy, onPlay, onMap, onSettings, progress }) {
  const g = GALAXIES[galaxy];
  return (
    <div style={{
      position: 'relative',
      width: '100%', height: '100%',
      background: `radial-gradient(ellipse at 50% 20%, ${g.nebulaA} 0%, transparent 55%),
                   radial-gradient(ellipse at 80% 80%, ${g.nebulaB} 0%, transparent 55%),
                   ${g.ink}`,
      overflow: 'hidden',
    }}>
      <Starfield density={80}/>
      <ConstellationLyra stroke={g.stroke} style={{opacity: 0.25}}/>

      <div style={{
        position: 'relative', zIndex: 2,
        padding: '24px 24px 32px',
        height: '100%',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Top bar */}
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11, letterSpacing: 2,
            color: g.accent, opacity: 0.85,
          }}>GALAXY · {g.name.toUpperCase()}</div>
          <button onClick={onSettings} style={iconBtn(g)}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
        </div>

        {/* Title / hero */}
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
          <div style={{fontSize: 13, letterSpacing: 3, opacity: 0.55, fontFamily: "'IBM Plex Mono', monospace"}}>
            A MATCH-3 ODYSSEY
          </div>
          <h1 style={{
            fontSize: 64, margin: '8px 0 4px',
            fontWeight: 500, letterSpacing: -2.5,
            lineHeight: 0.92,
          }}>Cosmic<br/>Match</h1>
          <div style={{
            marginTop: 16,
            display: 'flex', gap: 8, alignItems: 'center',
            fontFamily: "'IBM Plex Mono', monospace", fontSize: 11,
            opacity: 0.7,
          }}>
            <Dot c={g.accent}/> 50 levels · 5 galaxies · portrait only
          </div>
        </div>

        {/* Continue card */}
        <div style={{
          padding: '16px 18px',
          background: 'rgba(255,255,255,0.06)',
          backdropFilter: 'blur(10px)',
          border: `1px solid rgba(255,255,255,0.1)`,
          borderRadius: 16,
          marginBottom: 12,
        }}>
          <div style={{
            fontSize: 10, letterSpacing: 1.5, opacity: 0.55,
            fontFamily: "'IBM Plex Mono', monospace",
          }}>RESUME</div>
          <div style={{display: 'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop: 4}}>
            <div>
              <div style={{fontSize: 20, fontWeight: 500}}>Level {progress.current}</div>
              <div style={{fontSize: 12, opacity: 0.6, marginTop: 2}}>
                Lyra Sector · Clear 30 Neptunes
              </div>
            </div>
            <div style={{display:'flex', gap: 2}}>
              {[0,1,2].map(i => (
                <svg key={i} width="14" height="14" viewBox="0 0 24 24">
                  <polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9"
                    fill={i < progress.stars ? g.accent : 'transparent'}
                    stroke={g.accent} strokeWidth="1.5"/>
                </svg>
              ))}
            </div>
          </div>
        </div>

        {/* CTAs */}
        <button onClick={onPlay} style={{
          width: '100%', padding: '18px',
          background: g.accent, color: g.ink,
          border: 'none', borderRadius: 100,
          fontSize: 16, fontWeight: 600, letterSpacing: 0.5,
          cursor: 'pointer',
          boxShadow: `0 0 40px ${g.accent}40`,
          transition: 'transform 120ms',
        }}
        onMouseDown={e=>e.currentTarget.style.transform='scale(0.98)'}
        onMouseUp={e=>e.currentTarget.style.transform='scale(1)'}
        onMouseLeave={e=>e.currentTarget.style.transform='scale(1)'}>
          ▶  PLAY LEVEL {progress.current}
        </button>
        <button onClick={onMap} style={{
          width: '100%', padding: '14px', marginTop: 8,
          background: 'transparent', color: '#fff',
          border: '1px solid rgba(255,255,255,0.2)', borderRadius: 100,
          fontSize: 14, letterSpacing: 0.3, cursor: 'pointer',
        }}>Galaxy Map</button>
      </div>
    </div>
  );
}

function iconBtn(g) {
  return {
    width: 40, height: 40, borderRadius: 100,
    background: 'rgba(255,255,255,0.08)',
    border: '1px solid rgba(255,255,255,0.12)',
    color: '#fff', cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
}

function Dot({ c }) {
  return <span style={{
    display:'inline-block', width: 6, height: 6, borderRadius: 10,
    background: c, boxShadow: `0 0 8px ${c}`,
  }}/>;
}

function Starfield({ density = 60, seed = 1 }) {
  // deterministic pseudo-random stars
  const stars = React.useMemo(() => {
    const out = [];
    let s = seed * 9301 + 49297;
    const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    for (let i = 0; i < density; i++) {
      out.push({
        x: rnd() * 100, y: rnd() * 100,
        size: rnd() * 1.6 + 0.4,
        opacity: rnd() * 0.6 + 0.3,
      });
    }
    return out;
  }, [density, seed]);
  return (
    <div style={{position:'absolute', inset:0, pointerEvents:'none'}}>
      {stars.map((s, i) => (
        <div key={i} style={{
          position: 'absolute',
          left: `${s.x}%`, top: `${s.y}%`,
          width: s.size, height: s.size,
          borderRadius: 10,
          background: '#fff',
          opacity: s.opacity,
          boxShadow: s.size > 1.2 ? `0 0 3px #fff` : 'none',
          animation: `twinkle ${3 + (i % 4)}s ease-in-out infinite`,
          animationDelay: `${(i * 0.37) % 3}s`,
        }}/>
      ))}
    </div>
  );
}

// Decorative constellation — Lyra-ish (parallelogram + Vega)
function ConstellationLyra({ stroke, style }) {
  const pts = [
    {x: 30, y: 25}, {x: 55, y: 22}, {x: 68, y: 45},
    {x: 42, y: 50}, {x: 30, y: 25}, {x: 20, y: 15},
  ];
  return (
    <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none"
      style={{position:'absolute', inset:0, ...style}}>
      {pts.slice(0,-1).map((p, i) => {
        const n = pts[i+1];
        return <line key={i} x1={p.x} y1={p.y} x2={n.x} y2={n.y}
          stroke={stroke} strokeWidth="0.15" strokeDasharray="0.4 0.6"/>;
      })}
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={i === 0 ? 0.8 : 0.5}
          fill={stroke} opacity="0.8"/>
      ))}
    </svg>
  );
}

Object.assign(window, { HomeScreen, Starfield, ConstellationLyra, Dot });
