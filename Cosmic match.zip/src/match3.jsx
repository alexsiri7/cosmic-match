// Match-3 game logic — board generation, match detection, swap validation, cascades.
// Mirrors the repo's pattern_detector.dart priority:
// 1. 5-in-a-row → supernova, 2. L/T → blackhole, 3. 4-in-a-row → pulsar, 4. 3+ → clear

const TYPES = ['red', 'blue', 'yellow', 'purple', 'white', 'orange'];

function randTile() { return TYPES[Math.floor(Math.random() * TYPES.length)]; }

// Create a board with no initial matches
function makeBoard(size = 8) {
  const b = [];
  for (let r = 0; r < size; r++) {
    const row = [];
    for (let c = 0; c < size; c++) {
      let t;
      let tries = 0;
      do {
        t = randTile();
        tries++;
      } while (
        tries < 20 && (
          (c >= 2 && row[c-1]?.type === t && row[c-2]?.type === t) ||
          (r >= 2 && b[r-1][c].type === t && b[r-2][c].type === t)
        )
      );
      row.push({ type: t, bonus: null, id: Math.random().toString(36).slice(2,9) });
    }
    b.push(row);
  }
  return b;
}

// Find all matches on the board. Returns { toClear: Set of "r,c", bonuses: [{r,c,type}] }
function findMatches(board) {
  const N = board.length;
  const toClear = new Set();
  const bonuses = [];
  const claimed = new Set();

  // Gather horizontal and vertical runs
  const runs = [];
  // horizontal
  for (let r = 0; r < N; r++) {
    let c = 0;
    while (c < N) {
      const t = board[r][c]?.type;
      if (!t || board[r][c].bonus) { c++; continue; }
      let e = c;
      while (e < N && board[r][e]?.type === t && !board[r][e].bonus) e++;
      if (e - c >= 3) runs.push({ r, c, len: e - c, dir: 'h', type: t });
      c = e;
    }
  }
  // vertical
  for (let c = 0; c < N; c++) {
    let r = 0;
    while (r < N) {
      const t = board[r][c]?.type;
      if (!t || board[r][c].bonus) { r++; continue; }
      let e = r;
      while (e < N && board[e][c]?.type === t && !board[e][c].bonus) e++;
      if (e - r >= 3) runs.push({ r, c, len: e - r, dir: 'v', type: t });
      r = e;
    }
  }

  // Priority 1: 5-in-a-row → supernova
  for (const run of runs.filter(r => r.len >= 5)) {
    const cells = cellsOfRun(run);
    const anyClaimed = cells.some(k => claimed.has(k));
    if (anyClaimed) continue;
    cells.forEach(k => { toClear.add(k); claimed.add(k); });
    const [mr, mc] = cells[Math.floor(cells.length/2)].split(',').map(Number);
    bonuses.push({ r: mr, c: mc, type: 'supernova', tileType: run.type });
  }

  // Priority 2: L/T shape → blackhole
  // Detect by intersection of a 3+ horizontal and 3+ vertical run sharing a cell
  const hRuns = runs.filter(r => r.dir === 'h' && r.len >= 3);
  const vRuns = runs.filter(r => r.dir === 'v' && r.len >= 3);
  for (const h of hRuns) {
    for (const v of vRuns) {
      if (h.type !== v.type) continue;
      // intersect?
      if (v.c >= h.c && v.c < h.c + h.len &&
          h.r >= v.r && h.r < v.r + v.len) {
        const hCells = cellsOfRun(h);
        const vCells = cellsOfRun(v);
        if (hCells.some(k=>claimed.has(k)) || vCells.some(k=>claimed.has(k))) continue;
        hCells.concat(vCells).forEach(k => { toClear.add(k); claimed.add(k); });
        bonuses.push({ r: h.r, c: v.c, type: 'blackhole', tileType: h.type });
      }
    }
  }

  // Priority 3: 4-in-a-row → pulsar
  for (const run of runs.filter(r => r.len === 4)) {
    const cells = cellsOfRun(run);
    if (cells.some(k => claimed.has(k))) continue;
    cells.forEach(k => { toClear.add(k); claimed.add(k); });
    const [mr, mc] = cells[1].split(',').map(Number);
    bonuses.push({ r: mr, c: mc, type: 'pulsar', tileType: run.type });
  }

  // Priority 4: basic clears
  for (const run of runs.filter(r => r.len === 3)) {
    const cells = cellsOfRun(run);
    if (cells.some(k => claimed.has(k))) continue;
    cells.forEach(k => { toClear.add(k); claimed.add(k); });
  }

  return { toClear, bonuses };
}

function cellsOfRun(run) {
  const out = [];
  for (let i = 0; i < run.len; i++) {
    if (run.dir === 'h') out.push(`${run.r},${run.c+i}`);
    else out.push(`${run.r+i},${run.c}`);
  }
  return out;
}

// Apply gravity + refill. Returns new board.
function applyGravity(board) {
  const N = board.length;
  const next = board.map(row => row.slice());
  for (let c = 0; c < N; c++) {
    // collapse
    let write = N - 1;
    for (let r = N - 1; r >= 0; r--) {
      if (next[r][c] !== null) {
        const tile = next[r][c];
        next[r][c] = null;
        next[write][c] = tile;
        write--;
      }
    }
    // refill from top
    for (let r = write; r >= 0; r--) {
      next[r][c] = { type: randTile(), bonus: null, id: Math.random().toString(36).slice(2,9) };
    }
  }
  return next;
}

function clearCells(board, toClear, bonuses) {
  const next = board.map(row => row.slice());
  for (const k of toClear) {
    const [r, c] = k.split(',').map(Number);
    next[r][c] = null;
  }
  // Place bonus tiles
  for (const b of bonuses) {
    next[b.r][b.c] = {
      type: b.tileType,
      bonus: b.type,
      id: Math.random().toString(36).slice(2,9),
    };
  }
  return next;
}

// Is (r1,c1) adjacent to (r2,c2)?
function isAdjacent(a, b) {
  return Math.abs(a.r - b.r) + Math.abs(a.c - b.c) === 1;
}

function swapCells(board, a, b) {
  const next = board.map(r => r.slice());
  const tmp = next[a.r][a.c];
  next[a.r][a.c] = next[b.r][b.c];
  next[b.r][b.c] = tmp;
  return next;
}

Object.assign(window, {
  makeBoard, findMatches, applyGravity, clearCells,
  isAdjacent, swapCells, cellsOfRun, TYPES,
});
