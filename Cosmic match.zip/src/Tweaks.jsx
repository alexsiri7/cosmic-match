// Tweaks panel — floating controls, wired to host via postMessage.

function TweaksPanel({ state, onChange, visible, onClose }) {
  if (!visible) return null;
  return (
    <div style={{
      position: 'fixed', bottom: 20, right: 20, zIndex: 9999,
      width: 280, padding: 16,
      background: 'rgba(15,10,28,0.96)',
      border: '1px solid rgba(255,255,255,0.15)',
      borderRadius: 16,
      color: '#fff',
      fontFamily: "'Space Grotesk', system-ui, sans-serif",
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      backdropFilter: 'blur(16px)',
    }}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 14}}>
        <div style={{
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 11, letterSpacing: 2, opacity: 0.7,
        }}>TWEAKS</div>
        <button onClick={onClose} style={{
          width: 22, height: 22, borderRadius: 100,
          background: 'rgba(255,255,255,0.1)',
          border: 'none', color: '#fff', cursor: 'pointer',
          fontSize: 12, lineHeight: 1,
        }}>×</button>
      </div>

      <TweakGroup label="Galaxy">
        <SegmentedControl
          value={state.galaxy}
          onChange={v => onChange({galaxy: v})}
          options={[
            ['lyra', 'Lyra'], ['orion', 'Orion'],
            ['andromeda', 'Androm.'], ['cassiopeia', 'Cassio.']
          ]}/>
      </TweakGroup>

      <TweakGroup label="Tile style">
        <SegmentedControl
          value={state.tileStyle}
          onChange={v => onChange({tileStyle: v})}
          options={[['iconic', 'Iconic'], ['flat', 'Flat']]}/>
      </TweakGroup>

      <TweakGroup label="Screen">
        <SegmentedControl
          value={state.screen}
          onChange={v => onChange({screen: v})}
          options={[['home','Home'],['map','Map'],['game','Game']]}/>
      </TweakGroup>

      <TweakGroup label="Board">
        <SegmentedControl
          value={String(state.boardSize)}
          onChange={v => onChange({boardSize: parseInt(v)})}
          options={[['6','6×6'],['7','7×7'],['8','8×8']]}/>
      </TweakGroup>

      <TweakGroup label="Constellations">
        <SegmentedControl
          value={state.showConstellations ? 'on' : 'off'}
          onChange={v => onChange({showConstellations: v === 'on'})}
          options={[['on','On'],['off','Off']]}/>
      </TweakGroup>
    </div>
  );
}

function TweakGroup({ label, children }) {
  return (
    <div style={{marginBottom: 12}}>
      <div style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9, letterSpacing: 1.5, opacity: 0.55,
        marginBottom: 6,
      }}>{label.toUpperCase()}</div>
      {children}
    </div>
  );
}

function SegmentedControl({ value, onChange, options }) {
  return (
    <div style={{
      display: 'flex', gap: 4,
      padding: 3,
      background: 'rgba(255,255,255,0.06)',
      borderRadius: 8,
    }}>
      {options.map(([v, label]) => (
        <button key={v} onClick={() => onChange(v)} style={{
          flex: 1, padding: '6px 4px',
          background: value === v ? 'rgba(255,255,255,0.14)' : 'transparent',
          color: value === v ? '#fff' : 'rgba(255,255,255,0.6)',
          border: 'none', borderRadius: 6,
          fontSize: 11, fontWeight: 500,
          cursor: 'pointer',
          fontFamily: 'inherit',
        }}>{label}</button>
      ))}
    </div>
  );
}

Object.assign(window, { TweaksPanel });
