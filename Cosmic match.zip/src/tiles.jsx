// Tile component — distinct shape AND color per PRD accessibility.
// 6 shapes: circle (Mars), ringed planet (Neptune), 4-pt star (Sol),
// rounded lozenge (Nebula), crescent (Luna), teardrop/comet (Comet).
// Plus 3 bonus tiles with their own iconography.

function Tile({ type, size = 36, selected = false, hinted = false, clearing = false, bonus = null }) {
  if (bonus) return <BonusTile type={bonus} size={size} clearing={clearing} />;
  if (!type) return null;
  const t = TILES[type];
  const s = size;

  const shape = {
    red: <PlanetMars c={t.color} s={s} />,
    blue: <PlanetRinged c={t.color} s={s} />,
    yellow: <StarSol c={t.color} s={s} />,
    purple: <NebulaBlob c={t.color} s={s} />,
    white: <LunaCrescent c={t.color} s={s} />,
    orange: <CometIcon c={t.color} s={s} />,
  }[type];

  return (
    <div style={{
      width: s, height: s,
      position: 'relative',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      transition: 'transform 180ms cubic-bezier(.2,.9,.25,1.4), opacity 180ms',
      transform: selected ? 'scale(1.12)' : clearing ? 'scale(0.3)' : 'scale(1)',
      opacity: clearing ? 0 : 1,
      filter: hinted ? `drop-shadow(0 0 6px ${t.glow})` : 'none',
    }}>
      {selected && (
        <div style={{
          position: 'absolute', inset: -2,
          borderRadius: 12,
          border: `2px solid ${t.glow}`,
          boxShadow: `0 0 16px ${t.glow}, inset 0 0 10px ${t.glow}`,
          animation: 'tilepulse 900ms ease-in-out infinite',
        }}/>
      )}
      {shape}
    </div>
  );
}

// ─── Individual tile shapes ───────────────────────────────

function PlanetMars({ c, s }) {
  // filled circle with inner shadow/highlight + 2 crater dots
  const r = s * 0.38;
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`mars-${c}`} cx="35%" cy="30%">
          <stop offset="0%" stopColor="#fff" stopOpacity="0.4"/>
          <stop offset="40%" stopColor={c} stopOpacity="1"/>
          <stop offset="100%" stopColor={c} stopOpacity="1"/>
        </radialGradient>
      </defs>
      <circle cx={s/2} cy={s/2} r={r} fill={`url(#mars-${c})`}/>
      <circle cx={s/2 + r*0.3} cy={s/2 + r*0.2} r={r*0.12} fill="#000" opacity="0.18"/>
      <circle cx={s/2 - r*0.25} cy={s/2 - r*0.1} r={r*0.08} fill="#000" opacity="0.15"/>
    </svg>
  );
}

function PlanetRinged({ c, s }) {
  const r = s * 0.30;
  const cx = s/2, cy = s/2;
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`ring-${c}`} cx="35%" cy="30%">
          <stop offset="0%" stopColor="#fff" stopOpacity="0.5"/>
          <stop offset="50%" stopColor={c} stopOpacity="1"/>
          <stop offset="100%" stopColor={c} stopOpacity="1"/>
        </radialGradient>
      </defs>
      {/* back of ring */}
      <ellipse cx={cx} cy={cy} rx={r*1.7} ry={r*0.42}
        fill="none" stroke={c} strokeOpacity="0.9" strokeWidth={s*0.055}/>
      {/* planet body */}
      <circle cx={cx} cy={cy} r={r} fill={`url(#ring-${c})`}/>
      {/* front of ring (overlapping planet on bottom) */}
      <path d={`M ${cx - r*1.7},${cy} a ${r*1.7},${r*0.42} 0 0 0 ${r*3.4},0`}
        fill="none" stroke={c} strokeWidth={s*0.055} strokeLinecap="round"/>
    </svg>
  );
}

function StarSol({ c, s }) {
  // 4-point star with diamond center
  const cx = s/2, cy = s/2;
  const R = s * 0.42; // long points
  const r = s * 0.13; // waist
  const pts = [];
  for (let i = 0; i < 8; i++) {
    const rad = i * Math.PI / 4;
    const d = i % 2 === 0 ? R : r;
    pts.push(`${cx + Math.cos(rad - Math.PI/2) * d},${cy + Math.sin(rad - Math.PI/2) * d}`);
  }
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`star-${c}`}>
          <stop offset="0%" stopColor="#fff" stopOpacity="0.9"/>
          <stop offset="60%" stopColor={c} stopOpacity="1"/>
          <stop offset="100%" stopColor={c} stopOpacity="0.95"/>
        </radialGradient>
      </defs>
      <polygon points={pts.join(' ')} fill={`url(#star-${c})`}/>
      <circle cx={cx} cy={cy} r={s*0.07} fill="#fff" opacity="0.85"/>
    </svg>
  );
}

function NebulaBlob({ c, s }) {
  // rounded lozenge w/ cloudy inner
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`neb-${c}`} cx="50%" cy="50%">
          <stop offset="0%" stopColor="#fff" stopOpacity="0.35"/>
          <stop offset="50%" stopColor={c} stopOpacity="0.95"/>
          <stop offset="100%" stopColor={c} stopOpacity="0.7"/>
        </radialGradient>
      </defs>
      <rect x={s*0.14} y={s*0.14} width={s*0.72} height={s*0.72}
        rx={s*0.20} fill={`url(#neb-${c})`}/>
      {/* cloud wisps */}
      <ellipse cx={s*0.35} cy={s*0.38} rx={s*0.10} ry={s*0.05} fill="#fff" opacity="0.35"/>
      <ellipse cx={s*0.62} cy={s*0.60} rx={s*0.13} ry={s*0.06} fill="#fff" opacity="0.22"/>
    </svg>
  );
}

function LunaCrescent({ c, s }) {
  const cx = s/2, cy = s/2;
  const R = s * 0.38;
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`luna-${c}`} cx="35%" cy="30%">
          <stop offset="0%" stopColor="#fff" stopOpacity="1"/>
          <stop offset="100%" stopColor={c} stopOpacity="1"/>
        </radialGradient>
        <mask id={`mask-${s}`}>
          <rect width={s} height={s} fill="white"/>
          <circle cx={cx + R*0.45} cy={cy - R*0.12} r={R*0.92} fill="black"/>
        </mask>
      </defs>
      <circle cx={cx} cy={cy} r={R} fill={`url(#luna-${c})`} mask={`url(#mask-${s})`}/>
      {/* subtle craters */}
      <circle cx={cx - R*0.15} cy={cy + R*0.1} r={R*0.08} fill="#000" opacity="0.1" mask={`url(#mask-${s})`}/>
    </svg>
  );
}

function CometIcon({ c, s }) {
  // teardrop head + tail
  const cx = s/2, cy = s/2;
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <linearGradient id={`comet-tail-${c}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={c} stopOpacity="0"/>
          <stop offset="100%" stopColor={c} stopOpacity="0.8"/>
        </linearGradient>
        <radialGradient id={`comet-head-${c}`} cx="40%" cy="35%">
          <stop offset="0%" stopColor="#fff" stopOpacity="0.95"/>
          <stop offset="100%" stopColor={c} stopOpacity="1"/>
        </radialGradient>
      </defs>
      {/* tail */}
      <path d={`M ${s*0.15},${s*0.15} Q ${s*0.35},${s*0.4} ${cx},${cy}`}
        stroke={`url(#comet-tail-${c})`} strokeWidth={s*0.12} strokeLinecap="round" fill="none"/>
      <path d={`M ${s*0.10},${s*0.30} Q ${s*0.32},${s*0.45} ${cx-3},${cy+2}`}
        stroke={`url(#comet-tail-${c})`} strokeWidth={s*0.08} strokeLinecap="round" fill="none" opacity="0.7"/>
      {/* head */}
      <circle cx={cx + s*0.08} cy={cy + s*0.08} r={s*0.22} fill={`url(#comet-head-${c})`}/>
    </svg>
  );
}

// ─── Bonus tiles ──────────────────────────────────────────

function BonusTile({ type, size, clearing }) {
  const s = size;
  return (
    <div style={{
      width: s, height: s, position: 'relative',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      transition: 'transform 180ms, opacity 180ms',
      transform: clearing ? 'scale(0.3)' : 'scale(1)',
      opacity: clearing ? 0 : 1,
      animation: 'bonusspin 4s linear infinite',
    }}>
      {type === 'pulsar' && <PulsarSVG s={s}/>}
      {type === 'blackhole' && <BlackHoleSVG s={s}/>}
      {type === 'supernova' && <SupernovaSVG s={s}/>}
    </div>
  );
}

function PulsarSVG({ s }) {
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`pulsar-${s}`}>
          <stop offset="0%" stopColor="#fff"/>
          <stop offset="60%" stopColor="#FFF4C7"/>
          <stop offset="100%" stopColor="#F5C24B" stopOpacity="0.3"/>
        </radialGradient>
      </defs>
      <circle cx={s/2} cy={s/2} r={s*0.42} fill={`url(#pulsar-${s})`}/>
      {/* horizontal beam */}
      <rect x={0} y={s/2 - s*0.03} width={s} height={s*0.06} fill="#FFF4C7" opacity="0.85"/>
      <circle cx={s/2} cy={s/2} r={s*0.18} fill="#fff"/>
    </svg>
  );
}

function BlackHoleSVG({ s }) {
  const cx = s/2, cy = s/2;
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`bh-${s}`}>
          <stop offset="0%" stopColor="#000"/>
          <stop offset="70%" stopColor="#1a0f2e"/>
          <stop offset="100%" stopColor="#A96BE8" stopOpacity="0.4"/>
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={s*0.45} fill={`url(#bh-${s})`}/>
      <ellipse cx={cx} cy={cy} rx={s*0.42} ry={s*0.12} fill="none" stroke="#E4E2F5" strokeWidth="1.5" opacity="0.8"/>
      <ellipse cx={cx} cy={cy} rx={s*0.35} ry={s*0.08} fill="none" stroke="#A96BE8" strokeWidth="1" opacity="0.7"/>
      <circle cx={cx} cy={cy} r={s*0.18} fill="#000"/>
    </svg>
  );
}

function SupernovaSVG({ s }) {
  const cx = s/2, cy = s/2;
  const pts = [];
  for (let i = 0; i < 16; i++) {
    const rad = i * Math.PI / 8;
    const d = i % 2 === 0 ? s*0.46 : s*0.18;
    pts.push(`${cx + Math.cos(rad) * d},${cy + Math.sin(rad) * d}`);
  }
  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      <defs>
        <radialGradient id={`sn-${s}`}>
          <stop offset="0%" stopColor="#fff"/>
          <stop offset="40%" stopColor="#FF6BD0"/>
          <stop offset="100%" stopColor="#A96BE8" stopOpacity="0.3"/>
        </radialGradient>
      </defs>
      <polygon points={pts.join(' ')} fill={`url(#sn-${s})`}/>
      <circle cx={cx} cy={cy} r={s*0.12} fill="#fff"/>
    </svg>
  );
}

// Stylistic alt: flat geometric (no gradients) — for 'flat' tweak
function TileFlat({ type, size = 36, selected, clearing, bonus }) {
  if (bonus) return <BonusTile type={bonus} size={size} clearing={clearing}/>;
  if (!type) return null;
  const t = TILES[type];
  const s = size;
  const shape = {
    red: <circle cx={s/2} cy={s/2} r={s*0.36} fill={t.color}/>,
    blue: <g>
      <ellipse cx={s/2} cy={s/2} rx={s*0.44} ry={s*0.11} fill="none" stroke={t.color} strokeWidth="3"/>
      <circle cx={s/2} cy={s/2} r={s*0.28} fill={t.color}/>
    </g>,
    yellow: (() => {
      const pts = [];
      for (let i=0;i<8;i++){const r=i*Math.PI/4;const d=i%2===0?s*0.42:s*0.13;
        pts.push(`${s/2+Math.cos(r-Math.PI/2)*d},${s/2+Math.sin(r-Math.PI/2)*d}`);}
      return <polygon points={pts.join(' ')} fill={t.color}/>;
    })(),
    purple: <rect x={s*0.14} y={s*0.14} width={s*0.72} height={s*0.72} rx={s*0.20} fill={t.color}/>,
    white: <g>
      <circle cx={s/2} cy={s/2} r={s*0.36} fill={t.color}/>
      <circle cx={s/2+s*0.14} cy={s/2-s*0.04} r={s*0.32} fill="#0d0a1a"/>
    </g>,
    orange: <path d={`M ${s*0.2} ${s*0.8} Q ${s/2} ${s/2} ${s*0.75} ${s*0.25} Q ${s*0.9} ${s*0.5} ${s*0.65} ${s*0.7} Q ${s*0.5} ${s*0.55} ${s*0.2} ${s*0.8} Z`} fill={t.color}/>,
  }[type];
  return (
    <div style={{
      width: s, height: s, position: 'relative',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      transition: 'transform 180ms, opacity 180ms',
      transform: selected ? 'scale(1.12)' : clearing ? 'scale(0.3)' : 'scale(1)',
      opacity: clearing ? 0 : 1,
    }}>
      {selected && (
        <div style={{
          position: 'absolute', inset: -2, borderRadius: 10,
          border: `2px solid ${t.glow}`,
          boxShadow: `0 0 12px ${t.glow}`,
        }}/>
      )}
      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>{shape}</svg>
    </div>
  );
}

Object.assign(window, { Tile, TileFlat, BonusTile });
